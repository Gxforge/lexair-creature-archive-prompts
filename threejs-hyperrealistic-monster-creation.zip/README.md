# THE WATCHER

Experiencia interactiva de horror biológico construida con React, Vite y Three.js. La escena se genera de forma procedural en el navegador: no requiere modelos, imágenes ni servicios externos.

## Ejecutar en desarrollo

```bash
npm install
npm run dev
```

Abre la URL local que indica Vite (normalmente `http://localhost:5173`). Se necesita un navegador moderno con WebGL habilitado.

## Servir la versión estática

El build de Vite genera un `dist/index.html` autocontenido, con JavaScript y CSS integrados:

```bash
npm run build
python -m http.server 8080 --directory dist
```

Abre `http://localhost:8080`.

## Controles

- Arrastra con el ratón para orbitar alrededor de la criatura.
- Usa la rueda para acercar o alejar la cámara.
- Cambia a **Primera persona** para mirar con el ratón y moverte con `W`, `A`, `S`, `D` o las flechas.
- Acércate para elevar la agresividad y provocar un ataque; después de atacar, la entidad entra en recuperación antes de reaccionar otra vez.
- Cambia la calidad gráfica para ajustar la resolución interna, las sombras y las partículas.
- Pausa o reanuda las animaciones; **Reiniciar** restablece la cámara, la criatura y la IA.

## Arquitectura

- `src/scene/Monster.ts`: cuerpo deformado, pliegues, cicatrices, poros y boca articulada.
- `src/scene/EyeSystem.ts`: ojo principal, ojos secundarios, iris procedural, vasos y seguimiento del jugador.
- `src/scene/Tentacles.ts`: diez tentáculos basados en curvas Catmull-Rom, tubos dinámicos y ventosas.
- `src/scene/MonsterAI.ts`: máquina de estados `IDLE`, `WATCHING`, `CURIOUS`, `AGGRESSIVE`, `ATTACK` y `RECOVERY`.
- `src/scene/Environment.ts`: laboratorio, charcos, estructuras, niebla e iluminación de emergencia.
- `src/scene/CameraController.ts`: cámara orbital, zoom y movimiento en primera persona.
- `src/scene/Effects.ts`: partículas flotantes y vibración de cámara durante los ataques.
- `src/scene/SceneExperience.ts`: ciclo de render, calidad gráfica, eventos y liberación de recursos.
- `src/App.tsx` y `src/index.css`: interfaz de observación responsive y controles.

## Rendimiento

La resolución interna se limita según la calidad elegida. Los poros de la piel y los pernos repetidos usan `InstancedMesh`; las geometrías tubulares de los tentáculos se reutilizan y actualizan en lugar de reconstruirse en cada fotograma. Las sombras se reservan para calidad alta y las partículas se desactivan en calidad baja.

## Alcance visual

El bloom se aplica con `EffectComposer` y `UnrealBloomPass` en calidad media y alta. La niebla usa `FogExp2` como aproximación eficiente; no hay volúmenes físicos ni simulación de fluidos. La piel, el iris y el relieve se construyen con texturas canvas y geometría procedural en lugar de mapas externos o shaders GLSL. La entidad reacciona al jugador desde una posición fija y no usa navegación de colisiones por el laboratorio.