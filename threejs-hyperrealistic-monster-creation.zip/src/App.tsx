import { useCallback, useEffect, useRef, useState } from "react";
import type { ChangeEvent } from "react";
import { SceneExperience } from "./scene/SceneExperience";
import type { MonsterState, MonsterTelemetry, QualityPreset } from "./scene/types";
import type { ViewMode } from "./scene/CameraController";

const stateLabels: Record<MonsterState, string> = {
  IDLE: "EN REPOSO",
  WATCHING: "OBSERVANDO",
  CURIOUS: "EXAMINANDO",
  AGGRESSIVE: "HOSTIL",
  ATTACK: "ATAQUE",
  RECOVERY: "RECUPERANDO",
};

function EyeMark() {
  return (
    <svg viewBox="0 0 36 26" fill="none" aria-hidden="true">
      <path d="M2 13C6.4 6.3 11.7 3 18 3s11.6 3.3 16 10c-4.4 6.7-9.7 10-16 10S6.4 19.7 2 13Z" stroke="currentColor" strokeWidth="1.3" />
      <circle cx="18" cy="13" r="5.1" stroke="currentColor" strokeWidth="1.2" />
      <circle cx="18" cy="13" r="1.7" fill="currentColor" />
    </svg>
  );
}

function ResetIcon() {
  return (
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M3.1 8.2a7 7 0 1 1 .3 4.6M3 3.8v4.5h4.5" stroke="currentColor" strokeWidth="1.35" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function PauseIcon({ paused }: { paused: boolean }) {
  return paused ? (
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="m7.4 4.8 7.2 5.2-7.2 5.2V4.8Z" fill="currentColor" />
    </svg>
  ) : (
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M6.5 5.2v9.6M13.5 5.2v9.6" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
    </svg>
  );
}

function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const experienceRef = useRef<SceneExperience | null>(null);
  const [telemetry, setTelemetry] = useState<MonsterTelemetry>({
    state: "WATCHING",
    distance: 12.5,
    aggression: 0.18,
    threat: 0.18,
  });
  const [quality, setQuality] = useState<QualityPreset>("high");
  const [animations, setAnimations] = useState(true);
  const [viewMode, setViewMode] = useState<ViewMode>("orbit");
  const [sceneError, setSceneError] = useState("");

  const handleTelemetry = useCallback((nextTelemetry: MonsterTelemetry) => {
    setTelemetry(nextTelemetry);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return undefined;

    try {
      const experience = new SceneExperience(canvas, handleTelemetry);
      experienceRef.current = experience;
    } catch (error) {
      console.error("Unable to initialize the Three.js scene:", error);
      setSceneError("No se pudo iniciar WebGL. Prueba con un navegador compatible y aceleración gráfica activa.");
    }

    return () => {
      experienceRef.current?.dispose();
      experienceRef.current = null;
    };
  }, [handleTelemetry]);

  const chooseQuality = (event: ChangeEvent<HTMLSelectElement>) => {
    const nextQuality = event.target.value as QualityPreset;
    setQuality(nextQuality);
    experienceRef.current?.setQuality(nextQuality);
  };

  const toggleAnimations = () => {
    const next = !animations;
    setAnimations(next);
    experienceRef.current?.setActive(next);
  };

  const chooseView = (mode: ViewMode) => {
    setViewMode(mode);
    experienceRef.current?.setViewMode(mode);
  };

  const resetEncounter = () => {
    experienceRef.current?.reset();
    setAnimations(true);
    setViewMode("orbit");
    experienceRef.current?.setActive(true);
  };

  const state = telemetry.state;
  const threatPercent = Math.round(telemetry.threat * 100);

  return (
    <main className={`experience-shell state-${state.toLowerCase()}`}>
      <div className="scene-viewport" aria-label="Escena interactiva 3D de The Watcher">
        <canvas ref={canvasRef} className="scene-canvas" />
        {sceneError && <div className="scene-error" role="alert">{sceneError}</div>}
      </div>

      <div className="scene-vignette" />
      <div className="film-grain" />
      <div className="frame-corners" aria-hidden="true">
        <span /> <span /> <span /> <span />
      </div>

      <header className="top-bar">
        <div className="brand-lockup">
          <div className="brand-mark"><EyeMark /></div>
          <div>
            <div className="brand-name">NEXUS <span>CONTAINMENT</span></div>
            <div className="brand-subline">INSTITUTE FOR ANOMALOUS BIOLOGY</div>
          </div>
        </div>

        <div className="sector-readout">
          <span className="sector-line" />
          <span>COMPLEJO 09</span>
          <span className="sector-divider">/</span>
          <span>SALA DE OBSERVACIÓN</span>
        </div>

        <div className="live-readout">
          <span className="live-pip" />
          <span>SEÑAL EN VIVO</span>
          <span className="live-code">CAM-04</span>
        </div>
      </header>

      <section className="specimen-heading" aria-label="Identificación de la criatura">
        <div className="eyebrow"><span className="eyebrow-index">01</span> REGISTRO DE ENTIDAD</div>
        <h1><span>THE</span><strong>WATCHER</strong></h1>
        <div className="title-rule"><span /> EL DEVORADOR DE MIRADAS</div>
        <p className="specimen-note">No apartes la vista.<br />Parece responder a cada movimiento.</p>
        <div className="specimen-id"><span>CLASIFICACIÓN</span><b>ORGANISMO HOSTIL / W-01</b></div>
      </section>

      <aside className="telemetry-panel" aria-label="Lecturas de la entidad">
        <div className="panel-caption"><span className="caption-dot" /> LECTURAS EN TIEMPO REAL</div>
        <div className="readout-state">
          <span className="readout-label">ESTADO DE LA ENTIDAD</span>
          <span className={`state-value state-text-${state.toLowerCase()}`}>{stateLabels[state]}</span>
        </div>

        <div className="threat-readout">
          <div className="threat-copy">
            <span className="readout-label">ÍNDICE DE AMENAZA</span>
            <span className="threat-number">{String(threatPercent).padStart(2, "0")}<small>%</small></span>
          </div>
          <div
            className="threat-track"
            role="meter"
            aria-label="Índice de amenaza"
            aria-valuemin={0}
            aria-valuemax={100}
            aria-valuenow={threatPercent}
          >
            <span style={{ height: `${threatPercent}%` }} />
          </div>
        </div>

        <div className="distance-readout">
          <span className="readout-label">DISTANCIA AL SUJETO</span>
          <div><strong>{telemetry.distance.toFixed(1)}</strong><small> M</small></div>
        </div>
        <div className="panel-footnote"><span>PROXIMIDAD</span><b>{telemetry.distance < 5 ? "CRÍTICA" : telemetry.distance < 8 ? "ELEVADA" : "ESTABLE"}</b></div>
      </aside>

      <div className="center-reticle" aria-hidden="true">
        <span className="reticle-core" />
      </div>

      <footer className="control-dock">
        <div className="dock-status">
          <div className={`status-orb ${state === "ATTACK" || state === "AGGRESSIVE" ? "status-orb-hot" : ""}`}>
            <span />
          </div>
          <div className="dock-status-copy">
            <span className="dock-label">PROTOCOLO DE CONTENCIÓN</span>
            <strong>{animations ? stateLabels[state] : "ANIMACIÓN EN PAUSA"}</strong>
          </div>
        </div>

        <div className="view-controls">
          <span className="dock-label">PUNTO DE VISTA</span>
          <div className="view-switch" role="group" aria-label="Modo de cámara">
            <button className={viewMode === "orbit" ? "selected" : ""} onClick={() => chooseView("orbit")}>
              <span className="view-icon orbit-icon" /> ÓRBITA
            </button>
            <button className={viewMode === "first-person" ? "selected" : ""} onClick={() => chooseView("first-person")}>
              <span className="view-icon first-person-icon" /> PRIMERA PERSONA
            </button>
          </div>
          <span className="view-hint">{viewMode === "orbit" ? "ARRASTRA PARA ORBITAR · RUEDA PARA ACERCAR" : "W A S D PARA MOVERTE · RATÓN PARA MIRAR"}</span>
        </div>

        <div className="dock-actions">
          <label className="quality-control">
            <span className="dock-label">CALIDAD</span>
            <select value={quality} onChange={chooseQuality} aria-label="Calidad gráfica">
              <option value="low">BAJA</option>
              <option value="medium">MEDIA</option>
              <option value="high">ALTA</option>
            </select>
          </label>
          <button className={`icon-action ${animations ? "is-active" : ""}`} onClick={toggleAnimations} aria-label={animations ? "Pausar animaciones" : "Reanudar animaciones"} title={animations ? "Pausar" : "Reanudar"}>
            <PauseIcon paused={!animations} />
          </button>
          <button className="reset-action" onClick={resetEncounter}>
            <ResetIcon /> <span>REINICIAR</span>
          </button>
        </div>
      </footer>

      <div className="bottom-coordinate" aria-hidden="true">N 04° 18' 52.1" &nbsp; E 17° 06' 09.4"</div>
      <div className="bottom-version" aria-hidden="true">OBSERVATION SYSTEM / V.2.4.09</div>
    </main>
  );
}

export default App;