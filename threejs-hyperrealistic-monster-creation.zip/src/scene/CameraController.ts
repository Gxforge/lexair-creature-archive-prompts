import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";

export type ViewMode = "orbit" | "first-person";

export class CameraController {
  readonly controls: OrbitControls;
  private mode: ViewMode = "orbit";
  private focalPoint = new THREE.Vector3(0, 2.36, 0);
  private firstPosition = new THREE.Vector3(0, 1.72, 9.6);
  private yaw = 0;
  private pitch = 0.055;
  private keys = new Set<string>();
  private pointer = new THREE.Vector2(0.5, 0.5);
  private onKeyDown = (event: KeyboardEvent): void => {
    const key = event.key.toLowerCase();
    if (["w", "a", "s", "d", "arrowup", "arrowdown", "arrowleft", "arrowright"].includes(key)) {
      this.keys.add(key);
      if (this.mode === "first-person") event.preventDefault();
    }
  };
  private onKeyUp = (event: KeyboardEvent): void => {
    this.keys.delete(event.key.toLowerCase());
  };
  private onPointerMove = (event: PointerEvent): void => {
    if (this.mode !== "first-person") return;
    this.pointer.set(event.clientX / Math.max(1, window.innerWidth), event.clientY / Math.max(1, window.innerHeight));
  };
  private onWheel = (event: WheelEvent): void => {
    if (this.mode !== "first-person") return;
    this.firstPosition.z = THREE.MathUtils.clamp(this.firstPosition.z + Math.sign(event.deltaY) * 0.6, 2.8, 15);
  };

  constructor(private camera: THREE.PerspectiveCamera, canvas: HTMLCanvasElement) {
    this.controls = new OrbitControls(camera, canvas);
    this.controls.target.copy(this.focalPoint);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.06;
    this.controls.enablePan = false;
    this.controls.minDistance = 3.1;
    this.controls.maxDistance = 18;
    this.controls.minPolarAngle = 0.38;
    this.controls.maxPolarAngle = Math.PI * 0.49;
    this.controls.rotateSpeed = 0.48;
    this.controls.zoomSpeed = 0.7;
    this.camera.position.set(0, 3.2, 12.7);
    this.controls.update();

    window.addEventListener("keydown", this.onKeyDown, { passive: false });
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("pointermove", this.onPointerMove);
    window.addEventListener("wheel", this.onWheel, { passive: true });
  }

  get viewMode(): ViewMode {
    return this.mode;
  }

  setMode(mode: ViewMode): void {
    if (mode === this.mode) return;
    this.mode = mode;
    this.keys.clear();

    if (mode === "first-person") {
      const target = this.controls.target;
      this.focalPoint.copy(target);
      this.firstPosition.set(0, 1.72, 9.2);
      this.yaw = 0;
      this.pitch = 0.055;
      this.pointer.set(0.5, 0.5);
      this.controls.enabled = false;
    } else {
      this.controls.enabled = true;
      this.camera.position.set(0, 3.2, 12.7);
      this.controls.target.copy(this.focalPoint);
      this.controls.update();
    }
  }

  update(delta: number): void {
    if (this.mode === "orbit") {
      this.controls.update();
      return;
    }

    const sensitivity = 0.9;
    const targetYaw = (this.pointer.x - 0.5) * sensitivity;
    const targetPitch = (0.5 - this.pointer.y) * 0.42;
    this.yaw = THREE.MathUtils.damp(this.yaw, targetYaw, 4.2, delta);
    this.pitch = THREE.MathUtils.damp(this.pitch, targetPitch, 4.2, delta);

    const forward = new THREE.Vector3(Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    const right = new THREE.Vector3(Math.cos(this.yaw), 0, Math.sin(this.yaw));
    const speed = 3.4 * delta;
    if (this.keys.has("w") || this.keys.has("arrowup")) this.firstPosition.addScaledVector(forward, speed);
    if (this.keys.has("s") || this.keys.has("arrowdown")) this.firstPosition.addScaledVector(forward, -speed);
    if (this.keys.has("a") || this.keys.has("arrowleft")) this.firstPosition.addScaledVector(right, -speed);
    if (this.keys.has("d") || this.keys.has("arrowright")) this.firstPosition.addScaledVector(right, speed);
    this.firstPosition.x = THREE.MathUtils.clamp(this.firstPosition.x, -5.2, 5.2);
    this.firstPosition.z = THREE.MathUtils.clamp(this.firstPosition.z, 2.6, 16);

    this.camera.position.copy(this.firstPosition);
    const lookDistance = 10;
    this.camera.lookAt(
      this.firstPosition.x + Math.sin(this.yaw) * lookDistance,
      this.firstPosition.y + Math.sin(this.pitch) * lookDistance,
      this.firstPosition.z - Math.cos(this.yaw) * lookDistance,
    );
  }

  getPlayerPosition(target = new THREE.Vector3()): THREE.Vector3 {
    return target.copy(this.camera.position);
  }

  getDistance(): number {
    return this.camera.position.distanceTo(this.focalPoint);
  }

  reset(): void {
    this.setMode("orbit");
    this.controls.reset();
    this.camera.position.set(0, 3.2, 12.7);
    this.controls.target.set(0, 2.36, 0);
    this.controls.update();
  }

  dispose(): void {
    this.controls.dispose();
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("pointermove", this.onPointerMove);
    window.removeEventListener("wheel", this.onWheel);
  }
}