import * as THREE from "three";
import type { QualityPreset } from "./types";

export class Effects {
  readonly group = new THREE.Group();
  private points: THREE.Points<THREE.BufferGeometry, THREE.PointsMaterial>;
  private positions: Float32Array;
  private velocities: Float32Array;
  private spread = 170;

  constructor() {
    this.group.name = "biological-dust";
    this.positions = new Float32Array(this.spread * 3);
    this.velocities = new Float32Array(this.spread);

    for (let i = 0; i < this.spread; i += 1) {
      this.positions[i * 3] = (Math.random() - 0.5) * 18;
      this.positions[i * 3 + 1] = Math.random() * 7.2;
      this.positions[i * 3 + 2] = (Math.random() - 0.5) * 15 - 1;
      this.velocities[i] = 0.08 + Math.random() * 0.26;
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute("position", new THREE.BufferAttribute(this.positions, 3));
    this.points = new THREE.Points(
      geometry,
      new THREE.PointsMaterial({
        color: 0xa88e87,
        size: 0.045,
        transparent: true,
        opacity: 0.62,
        depthWrite: false,
        sizeAttenuation: true,
        blending: THREE.AdditiveBlending,
      }),
    );
    this.group.add(this.points);
  }

  setQuality(quality: QualityPreset): void {
    this.points.visible = quality !== "low";
    this.points.material.size = quality === "high" ? 0.05 : 0.038;
    this.points.material.opacity = quality === "high" ? 0.66 : 0.48;
  }

  update(time: number, delta: number, camera: THREE.Camera, attackDrive: number): void {
    for (let i = 0; i < this.spread; i += 1) {
      const offset = i * 3;
      this.positions[offset + 1] += this.velocities[i] * delta;
      this.positions[offset] += Math.sin(time * 0.42 + i * 5.1) * delta * 0.035;
      if (this.positions[offset + 1] > 7.3) this.positions[offset + 1] = 0.08;
    }
    this.points.geometry.getAttribute("position").needsUpdate = true;

    if (attackDrive > 0.08) {
      const shake = attackDrive * 0.028;
      camera.position.x += Math.sin(time * 48) * shake;
      camera.position.y += Math.cos(time * 41) * shake * 0.62;
    }
  }
}