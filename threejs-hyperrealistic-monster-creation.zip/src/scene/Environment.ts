import * as THREE from "three";
import { createFloorTexture } from "./materials";

function addBox(
  parent: THREE.Object3D,
  geometry: THREE.BoxGeometry,
  material: THREE.Material,
  position: THREE.Vector3,
  scale: THREE.Vector3,
): THREE.Mesh {
  const mesh = new THREE.Mesh(geometry, material);
  mesh.position.copy(position);
  mesh.scale.copy(scale);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}

function addPipe(
  parent: THREE.Object3D,
  start: THREE.Vector3,
  end: THREE.Vector3,
  radius: number,
  material: THREE.Material,
): THREE.Mesh {
  const direction = end.clone().sub(start);
  const mesh = new THREE.Mesh(
    new THREE.CylinderGeometry(radius, radius, direction.length(), 12, 1),
    material,
  );
  mesh.position.copy(start).add(end).multiplyScalar(0.5);
  mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), direction.normalize());
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}

export class Environment {
  readonly group = new THREE.Group();
  readonly emergencyLights: THREE.PointLight[] = [];
  readonly allLights: THREE.Light[] = [];

  constructor(private scene: THREE.Scene) {
    this.group.name = "abandoned-laboratory";
    this.createRoom();
    this.createLights();
    this.scene.add(this.group);
  }

  private createRoom(): void {
    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(64, 64),
      new THREE.MeshPhysicalMaterial({
        map: createFloorTexture(),
        color: 0xabb6b1,
        roughness: 0.25,
        metalness: 0.26,
        clearcoat: 0.48,
        clearcoatRoughness: 0.12,
      }),
    );
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -0.06;
    floor.receiveShadow = true;
    this.group.add(floor);

    const concrete = new THREE.MeshStandardMaterial({ color: 0x292b2b, roughness: 0.93, metalness: 0.04 });
    const concreteDark = new THREE.MeshStandardMaterial({ color: 0x171a1a, roughness: 0.82, metalness: 0.16 });
    const steel = new THREE.MeshStandardMaterial({ color: 0x414442, roughness: 0.49, metalness: 0.72 });
    const rust = new THREE.MeshStandardMaterial({ color: 0x472a25, roughness: 0.72, metalness: 0.28 });
    const redEmitter = new THREE.MeshStandardMaterial({
      color: 0xa71924,
      emissive: 0xc72230,
      emissiveIntensity: 2.2,
      roughness: 0.28,
    });
    const box = new THREE.BoxGeometry(1, 1, 1);

    addBox(this.group, box, concrete, new THREE.Vector3(0, 4.25, -5.75), new THREE.Vector3(32, 8.6, 0.8));
    addBox(this.group, box, concreteDark, new THREE.Vector3(-15.6, 4.1, 3), new THREE.Vector3(0.8, 8.2, 20));
    addBox(this.group, box, concreteDark, new THREE.Vector3(15.6, 4.1, 3), new THREE.Vector3(0.8, 8.2, 20));

    for (let i = 0; i < 9; i += 1) {
      const x = -12 + i * 3;
      addBox(this.group, box, steel, new THREE.Vector3(x, 4.15, -5.1), new THREE.Vector3(0.11, 8.2, 0.14));
      addBox(this.group, box, concreteDark, new THREE.Vector3(x + 1.45, 3.95, -5.26), new THREE.Vector3(2.75, 7.8, 0.1));
      addBox(this.group, box, rust, new THREE.Vector3(x + 0.02, 0.62, -4.95), new THREE.Vector3(0.24, 1.15, 0.5));
    }

    addBox(this.group, box, steel, new THREE.Vector3(0, 7.9, -5.05), new THREE.Vector3(32, 0.18, 0.34));
    addBox(this.group, box, steel, new THREE.Vector3(0, 0.34, -5.08), new THREE.Vector3(32, 0.48, 0.35));

    for (let i = 0; i < 5; i += 1) {
      const x = -8 + i * 4;
      addPipe(this.group, new THREE.Vector3(x, 0.5, -4.35), new THREE.Vector3(x, 6.8, -4.35), 0.085, steel);
      addPipe(this.group, new THREE.Vector3(x, 6.8, -4.35), new THREE.Vector3(x + 0.65, 7.15, -4.35), 0.085, rust);
      addBox(this.group, box, redEmitter, new THREE.Vector3(x, 7.34, -4.85), new THREE.Vector3(1.15, 0.07, 0.12));
    }

    addPipe(this.group, new THREE.Vector3(-14, 6.25, -4.55), new THREE.Vector3(12, 6.25, -4.55), 0.12, rust);
    addPipe(this.group, new THREE.Vector3(-13, 5.78, -4.58), new THREE.Vector3(14, 5.78, -4.58), 0.055, steel);
    addPipe(this.group, new THREE.Vector3(-8, 6.25, -4.5), new THREE.Vector3(-8, 5.4, -4.5), 0.06, steel);
    addPipe(this.group, new THREE.Vector3(7, 6.25, -4.5), new THREE.Vector3(7, 4.8, -4.5), 0.06, steel);

    const crackMaterial = new THREE.MeshStandardMaterial({ color: 0x101313, roughness: 1 });
    const crackPaths = [
      [new THREE.Vector3(-10.5, 6.3, -5.31), new THREE.Vector3(-9.9, 5.9, -5.31), new THREE.Vector3(-10.2, 5.2, -5.31), new THREE.Vector3(-9.55, 4.8, -5.31)],
      [new THREE.Vector3(9.4, 5.7, -5.31), new THREE.Vector3(9.1, 5.25, -5.31), new THREE.Vector3(9.8, 4.75, -5.31), new THREE.Vector3(9.7, 4.15, -5.31)],
      [new THREE.Vector3(-2.5, 7.1, -5.31), new THREE.Vector3(-2.1, 6.7, -5.31), new THREE.Vector3(-2.7, 6.2, -5.31)],
    ];
    for (const points of crackPaths) {
      this.group.add(new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points), 20, 0.018, 4, false), crackMaterial));
    }

    const puddleMaterial = new THREE.MeshPhysicalMaterial({
      color: 0x314345,
      transparent: true,
      opacity: 0.5,
      roughness: 0.12,
      metalness: 0.42,
      clearcoat: 1,
      clearcoatRoughness: 0.04,
      depthWrite: false,
    });
    for (let i = 0; i < 13; i += 1) {
      const puddle = new THREE.Mesh(new THREE.CircleGeometry(1, 9 + (i % 6)), puddleMaterial);
      puddle.rotation.x = -Math.PI / 2;
      puddle.rotation.z = i * 0.73;
      puddle.position.set((Math.random() - 0.5) * 24, -0.025 + i * 0.0003, 4 - Math.random() * 14);
      puddle.scale.set(0.45 + Math.random() * 1.8, 0.25 + Math.random() * 0.75, 1);
      this.group.add(puddle);
    }

    const drain = new THREE.MeshStandardMaterial({ color: 0x171a1a, roughness: 0.52, metalness: 0.58 });
    for (let i = -2; i <= 2; i += 1) {
      const grate = addBox(
        this.group,
        box,
        drain,
        new THREE.Vector3(i * 0.12, 0.005, -3.7),
        new THREE.Vector3(0.045, 0.025, 1.2),
      );
      grate.rotation.y = 0.08;
    }

    const boltGeometry = new THREE.SphereGeometry(0.038, 8, 6);
    const bolts = new THREE.InstancedMesh(boltGeometry, steel, 90);
    const dummy = new THREE.Object3D();
    let boltIndex = 0;
    for (let x = -14; x <= 14; x += 2) {
      for (const y of [0.72, 7.56]) {
        dummy.position.set(x, y, -4.84);
        dummy.scale.set(1, 1, 0.5);
        dummy.updateMatrix();
        bolts.setMatrixAt(boltIndex, dummy.matrix);
        boltIndex += 1;
      }
    }
    bolts.count = boltIndex;
    this.group.add(bolts);
  }

  private createLights(): void {
    const ambient = new THREE.AmbientLight(0x667276, 0.52);
    const main = new THREE.DirectionalLight(0xc3d1cb, 1.45);
    main.position.set(-4, 8, 6);
    main.castShadow = true;
    main.shadow.mapSize.set(1024, 1024);
    main.shadow.camera.left = -9;
    main.shadow.camera.right = 9;
    main.shadow.camera.top = 9;
    main.shadow.camera.bottom = -3;
    main.shadow.bias = -0.0004;

    const eyeSpot = new THREE.SpotLight(0xffc2a0, 76, 18, Math.PI / 5, 0.6, 1.2);
    eyeSpot.position.set(0.4, 6.4, 5.3);
    eyeSpot.target.position.set(0, 2.6, 0.1);
    eyeSpot.castShadow = true;
    eyeSpot.shadow.mapSize.set(512, 512);

    const redLeft = new THREE.PointLight(0xff2434, 34, 16, 1.7);
    redLeft.position.set(-6.2, 4.8, -2.8);
    const redRight = new THREE.PointLight(0xb91a27, 22, 13, 1.8);
    redRight.position.set(6.4, 3.2, -3.1);
    const fill = new THREE.PointLight(0x668d91, 18, 13, 1.8);
    fill.position.set(3.9, 4.4, 2.2);
    const floorBounce = new THREE.PointLight(0x783137, 12, 11, 2);
    floorBounce.position.set(-2.7, 0.65, 2.5);

    this.group.add(ambient, main, eyeSpot, eyeSpot.target, redLeft, redRight, fill, floorBounce);
    this.allLights.push(ambient, main, eyeSpot, redLeft, redRight, fill, floorBounce);
    this.emergencyLights.push(redLeft, redRight);
  }

  update(time: number, alert: number): void {
    const pulse = 0.92 + Math.sin(time * 4.2) * 0.04 + alert * 0.13 * Math.sin(time * 18);
    this.emergencyLights.forEach((light, index) => {
      light.intensity = (index === 0 ? 34 : 22) * pulse;
    });
  }
}