import * as THREE from "three";
import type { MaterialSet } from "./types";

interface EyeRig {
  root: THREE.Group;
  irisRig: THREE.Group;
  pupil: THREE.Mesh<THREE.CircleGeometry, THREE.MeshBasicMaterial>;
  phase: number;
  baseScale: number;
  isMain: boolean;
}

const clamp = THREE.MathUtils.clamp;

export class EyeSystem {
  readonly group = new THREE.Group();
  private eyes: EyeRig[] = [];
  private blinkTimer = 2.7;
  private blinkTime = 0;
  private blinkDuration = 0.2;

  constructor(private materials: MaterialSet) {
    this.group.name = "anatomical-eyes";
    this.addEye(new THREE.Vector3(0, 3.23, 1.06), 1.18, true, 0);
    this.addEye(new THREE.Vector3(-1.42, 2.68, 0.74), 0.37, false, 0.4);
    this.addEye(new THREE.Vector3(1.42, 2.76, 0.74), 0.39, false, 1.1);
    this.addEye(new THREE.Vector3(-0.93, 3.97, 0.47), 0.28, false, 2.2);
    this.addEye(new THREE.Vector3(0.94, 3.88, 0.52), 0.3, false, 0.8);
    this.addEye(new THREE.Vector3(-1.43, 2.05, 0.68), 0.26, false, 1.9);
    this.addEye(new THREE.Vector3(1.31, 2.1, 0.74), 0.29, false, 2.6);
  }

  private addEye(position: THREE.Vector3, size: number, isMain: boolean, phase: number): void {
    const root = new THREE.Group();
    root.position.copy(position);
    root.scale.setScalar(size);
    root.name = isMain ? "primary-eye" : "secondary-eye";

    const socket = new THREE.Mesh(new THREE.TorusGeometry(0.79, 0.13, 14, 64), this.materials.socket);
    socket.scale.set(1.28, 0.94, 0.62);
    socket.position.z = -0.045;
    root.add(socket);

    const globe = new THREE.Mesh(
      new THREE.SphereGeometry(1, 48, 32),
      this.materials.eyeWhite,
    );
    globe.scale.set(1.02, 0.74, 0.43);
    root.add(globe);

    this.addVeins(root, isMain ? 12 : 5);

    const irisRig = new THREE.Group();
    irisRig.position.set(0, 0, 0.445);
    root.add(irisRig);

    const iris = new THREE.Mesh(
      new THREE.CircleGeometry(0.385, 64),
      this.materials.iris,
    );
    iris.position.z = 0.008;
    irisRig.add(iris);

    const irisEdge = new THREE.Mesh(
      new THREE.TorusGeometry(0.36, 0.018, 8, 64),
      this.materials.socket,
    );
    irisEdge.position.z = 0.015;
    irisRig.add(irisEdge);

    const pupil = new THREE.Mesh(new THREE.CircleGeometry(0.165, 48), this.materials.pupil);
    pupil.position.z = 0.027;
    irisRig.add(pupil);

    const highlight = new THREE.Mesh(
      new THREE.SphereGeometry(0.046, 16, 12),
      new THREE.MeshBasicMaterial({ color: 0xfff5e9 }),
    );
    highlight.position.set(-0.11, 0.13, 0.055);
    irisRig.add(highlight);

    const cornea = new THREE.Mesh(
      new THREE.SphereGeometry(1, 32, 24),
      this.materials.cornea,
    );
    cornea.scale.set(0.46, 0.46, 0.11);
    cornea.position.set(0, 0, 0.407);
    root.add(cornea);

    const lowerFold = new THREE.Mesh(new THREE.TorusGeometry(0.78, 0.045, 8, 56), this.materials.skinLight);
    lowerFold.scale.set(1.25, 0.88, 0.32);
    lowerFold.rotation.x = 0.04;
    lowerFold.position.set(0, -0.04, 0.12);
    root.add(lowerFold);

    this.group.add(root);
    this.eyes.push({ root, irisRig, pupil, phase, baseScale: size, isMain });
  }

  private addVeins(root: THREE.Group, count: number): void {
    for (let i = 0; i < count; i += 1) {
      const angle = (i / count) * Math.PI * 2 + i * 1.73;
      const branch = i % 3 === 0;
      const points: THREE.Vector3[] = [];
      const startRadius = 0.88 + (i % 2) * 0.045;
      const endRadius = 0.42 + (i % 4) * 0.025;
      for (let j = 0; j < 5; j += 1) {
        const t = j / 4;
        const radius = THREE.MathUtils.lerp(startRadius, endRadius, t);
        const bend = Math.sin(t * Math.PI * 1.6 + i) * 0.045;
        const a = angle + bend;
        const x = Math.cos(a) * radius;
        const y = Math.sin(a) * radius * 0.64;
        const z = 0.43 * Math.sqrt(Math.max(0.025, 1 - x * x - (y / 0.74) ** 2)) + 0.012;
        points.push(new THREE.Vector3(x, y, z));
      }
      const curve = new THREE.CatmullRomCurve3(points);
      const vein = new THREE.Mesh(
        new THREE.TubeGeometry(curve, 12, branch ? 0.009 : 0.006, 5, false),
        this.materials.vein,
      );
      root.add(vein);
    }
  }

  update(time: number, delta: number, playerPosition: THREE.Vector3, aggression: number): void {
    this.blinkTimer -= delta;
    if (this.blinkTimer <= 0 && this.blinkTime <= 0) {
      this.blinkTime = this.blinkDuration;
      this.blinkTimer = 2.2 + Math.random() * 3.4;
    }

    const blinkProgress = this.blinkTime > 0
      ? Math.sin((1 - this.blinkTime / this.blinkDuration) * Math.PI)
      : 0;
    this.blinkTime = Math.max(0, this.blinkTime - delta);

    for (const eye of this.eyes) {
      const dx = playerPosition.x - eye.root.position.x;
      const dy = playerPosition.y - eye.root.position.y;
      const dz = playerPosition.z - eye.root.position.z;
      const look = 1 / Math.max(2.6, Math.hypot(dx, dy, dz));
      const tracking = eye.isMain ? 1 : 0.55;

      eye.irisRig.position.x = clamp(dx * look * 0.43 * tracking, -0.15, 0.15);
      eye.irisRig.position.y = clamp(dy * look * 0.34 * tracking, -0.12, 0.12);
      eye.root.rotation.y = clamp(dx * look * 0.13 * tracking, -0.16, 0.16);
      eye.root.rotation.x = clamp(-dy * look * 0.1 * tracking, -0.12, 0.12);

      const pupilScale = 0.88 + 0.17 * Math.sin(time * 0.77 + eye.phase) - aggression * 0.12;
      eye.pupil.scale.setScalar(clamp(pupilScale, 0.64, 1.08));
      const twitch = eye.isMain ? 1 : 0.45;
      eye.root.scale.y = eye.baseScale * (1 - blinkProgress * (0.78 * twitch));
      eye.root.scale.x = eye.baseScale * (1 + Math.sin(time * 2.1 + eye.phase) * 0.008 * twitch);
    }
  }
}