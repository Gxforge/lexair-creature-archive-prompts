import * as THREE from "three";
import { EyeSystem } from "./EyeSystem";
import { createMaterialSet } from "./materials";
import { Tentacles } from "./Tentacles";
import type { MonsterState } from "./types";

function makeOrganicGeometry(
  radius: THREE.Vector3,
  seed: number,
  widthSegments = 48,
  heightSegments = 36,
): THREE.BufferGeometry {
  const geometry = new THREE.SphereGeometry(1, widthSegments, heightSegments);
  const positions = geometry.getAttribute("position") as THREE.BufferAttribute;
  const vertex = new THREE.Vector3();

  for (let i = 0; i < positions.count; i += 1) {
    vertex.fromBufferAttribute(positions, i);
    const wave = Math.sin(vertex.x * 7.3 + seed) * Math.sin(vertex.y * 5.7 - seed * 0.7);
    const ridges = Math.sin(vertex.y * 14 + vertex.z * 4 + seed) * 0.025;
    const wobble = 1 + wave * 0.055 + ridges + Math.cos(vertex.x * 12 + vertex.z * 9) * 0.018;
    positions.setXYZ(i, vertex.x * radius.x * wobble, vertex.y * radius.y * wobble, vertex.z * radius.z * wobble);
  }

  geometry.computeVertexNormals();
  return geometry;
}

function addTube(
  parent: THREE.Object3D,
  points: THREE.Vector3[],
  radius: number,
  material: THREE.Material,
  segments = 32,
): THREE.Mesh {
  const curve = new THREE.CatmullRomCurve3(points);
  const mesh = new THREE.Mesh(new THREE.TubeGeometry(curve, segments, radius, 7, false), material);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}

export class Monster {
  readonly group = new THREE.Group();
  readonly materials = createMaterialSet();
  private body: THREE.Mesh<THREE.BufferGeometry, THREE.MeshPhysicalMaterial>;
  private eyes: EyeSystem;
  private tentacles: Tentacles;
  private maw: THREE.Group;
  private mouthOpening!: THREE.Mesh<THREE.SphereGeometry, THREE.MeshStandardMaterial>;
  private lowerJaw!: THREE.Group;
  private salivaGroup!: THREE.Group;
  private salivaMaterial!: THREE.MeshPhysicalMaterial;
  private bodyParts: THREE.Mesh[] = [];

  constructor() {
    this.group.name = "the-watcher-monster";
    this.body = new THREE.Mesh(
      makeOrganicGeometry(new THREE.Vector3(1.92, 2.12, 1.23), 1.7, 72, 52),
      this.materials.skin,
    );
    this.body.position.y = 2.38;
    this.body.castShadow = true;
    this.body.receiveShadow = true;
    this.group.add(this.body);

    this.createFleshFolds();
    this.createSurfaceDetail();

    this.eyes = new EyeSystem(this.materials);
    this.group.add(this.eyes.group);
    this.maw = this.createMouth();
    this.group.add(this.maw);

    this.tentacles = new Tentacles(this.materials);
    this.group.add(this.tentacles.group);

    const shadowCanvas = document.createElement("canvas");
    shadowCanvas.width = 128;
    shadowCanvas.height = 128;
    const shadowContext = shadowCanvas.getContext("2d");
    if (shadowContext) {
      const gradient = shadowContext.createRadialGradient(64, 64, 5, 64, 64, 64);
      gradient.addColorStop(0, "rgba(0, 0, 0, .62)");
      gradient.addColorStop(0.42, "rgba(0, 0, 0, .29)");
      gradient.addColorStop(1, "rgba(0, 0, 0, 0)");
      shadowContext.fillStyle = gradient;
      shadowContext.fillRect(0, 0, 128, 128);
    }
    const shadowTexture = new THREE.CanvasTexture(shadowCanvas);
    const shadow = new THREE.Mesh(
      new THREE.CircleGeometry(2.5, 48),
      new THREE.MeshBasicMaterial({ map: shadowTexture, transparent: true, opacity: 0.86, depthWrite: false }),
    );
    shadow.rotation.x = -Math.PI / 2;
    shadow.position.set(0, 0.018, 0.16);
    shadow.scale.set(1.65, 0.74, 1);
    this.group.add(shadow);
  }

  private createFleshFolds(): void {
    const collar = new THREE.Mesh(
      makeOrganicGeometry(new THREE.Vector3(1.43, 0.73, 0.72), 5.1, 48, 32),
      this.materials.skinLight,
    );
    collar.position.set(0, 3.15, 0.36);
    collar.scale.set(1, 0.68, 0.88);
    collar.castShadow = true;
    this.group.add(collar);
    this.bodyParts.push(collar);

    for (const side of [-1, 1]) {
      const shoulder = new THREE.Mesh(
        makeOrganicGeometry(new THREE.Vector3(0.61, 1.02, 0.68), 2.3 + side, 36, 28),
        this.materials.skin,
      );
      shoulder.position.set(side * 1.48, 2.42, 0.18);
      shoulder.rotation.z = -side * 0.13;
      shoulder.castShadow = true;
      shoulder.receiveShadow = true;
      this.group.add(shoulder);
      this.bodyParts.push(shoulder);

      const foldPoints = [
        new THREE.Vector3(side * 1.9, 3.72, 0.32),
        new THREE.Vector3(side * 1.55, 3.48, 0.94),
        new THREE.Vector3(side * 1.32, 2.95, 1.1),
        new THREE.Vector3(side * 1.7, 2.57, 0.91),
        new THREE.Vector3(side * 1.93, 2.2, 0.55),
      ];
      addTube(this.group, foldPoints, 0.075, this.materials.skinLight, 28);
    }

    const upperBrow = [
      new THREE.Vector3(-1.18, 3.85, 1.05),
      new THREE.Vector3(-0.72, 4.08, 1.18),
      new THREE.Vector3(0, 4.14, 1.2),
      new THREE.Vector3(0.7, 4.07, 1.17),
      new THREE.Vector3(1.18, 3.8, 1.02),
    ];
    addTube(this.group, upperBrow, 0.12, this.materials.skin, 36);

    const scarMaterial = new THREE.MeshStandardMaterial({ color: 0x411e25, roughness: 0.72 });
    addTube(this.group, [
      new THREE.Vector3(-1.65, 2.15, 0.89),
      new THREE.Vector3(-1.35, 2.0, 1.11),
      new THREE.Vector3(-1.08, 1.88, 1.06),
      new THREE.Vector3(-0.91, 1.68, 0.96),
    ], 0.022, scarMaterial, 22);
    addTube(this.group, [
      new THREE.Vector3(1.65, 3.06, 0.8),
      new THREE.Vector3(1.42, 3.23, 1.03),
      new THREE.Vector3(1.17, 3.22, 1.08),
      new THREE.Vector3(1.02, 3.38, 1.02),
    ], 0.026, scarMaterial, 22);
  }

  private createSurfaceDetail(): void {
    const pores = new THREE.InstancedMesh(
      new THREE.SphereGeometry(1, 8, 6),
      this.materials.pore,
      150,
    );
    const dummy = new THREE.Object3D();
    const normal = new THREE.Vector3();
    const up = new THREE.Vector3(0, 0, 1);
    let count = 0;

    for (let i = 0; i < 480 && count < 150; i += 1) {
      const x = (Math.random() * 2 - 1) * 1.78;
      const y = (Math.random() * 2 - 1) * 1.92;
      const normalized = (x * x) / (1.92 * 1.92) + (y * y) / (2.12 * 2.12);
      if (normalized > 0.84) continue;
      const worldY = y + 2.38;
      if (Math.abs(x) < 1.04 && worldY > 2.55 && worldY < 4.12) continue;
      if (Math.abs(x) < 0.7 && worldY > 1.35 && worldY < 2.02) continue;

      const z = 1.23 * Math.sqrt(1 - normalized);
      dummy.position.set(x, worldY, z + 0.01);
      normal.set(x / 3.68, y / 4.49, z / 1.51).normalize();
      dummy.quaternion.setFromUnitVectors(up, normal);
      const size = 0.018 + Math.random() * 0.025;
      dummy.scale.set(size * 1.15, size * 0.72, size * 0.35);
      dummy.updateMatrix();
      pores.setMatrixAt(count, dummy.matrix);
      count += 1;
    }

    pores.count = count;
    pores.instanceMatrix.needsUpdate = true;
    this.group.add(pores);

    const noduleMaterial = new THREE.MeshPhysicalMaterial({
      color: 0x9e6268,
      roughness: 0.32,
      clearcoat: 0.7,
    });
    for (let i = 0; i < 9; i += 1) {
      const side = i % 2 === 0 ? -1 : 1;
      const nodule = new THREE.Mesh(
        new THREE.SphereGeometry(0.13 + (i % 3) * 0.035, 18, 14),
        noduleMaterial,
      );
      const y = 1.6 + (i * 0.47) % 2.55;
      nodule.position.set(side * (1.68 - (i % 3) * 0.13), y, 0.69 + (i % 2) * 0.14);
      nodule.scale.set(1.2, 0.78, 0.6);
      nodule.rotation.z = side * 0.2;
      this.group.add(nodule);
    }
  }

  private createMouth(): THREE.Group {
    const mouth = new THREE.Group();
    mouth.name = "secondary-maw";
    mouth.position.set(0, 1.63, 1.19);

    const opening = new THREE.Mesh(new THREE.SphereGeometry(1, 36, 24), this.materials.mouth);
    opening.scale.set(0.71, 0.24, 0.17);
    mouth.add(opening);
    this.mouthOpening = opening;

    const lipMaterial = this.materials.skinLight;
    const upperLip = [
      new THREE.Vector3(-0.72, 0.01, 0),
      new THREE.Vector3(-0.48, 0.17, 0.055),
      new THREE.Vector3(-0.18, 0.21, 0.075),
      new THREE.Vector3(0.18, 0.2, 0.075),
      new THREE.Vector3(0.5, 0.14, 0.045),
      new THREE.Vector3(0.72, -0.01, 0),
    ];
    addTube(mouth, upperLip, 0.07, lipMaterial, 28);

    this.lowerJaw = new THREE.Group();
    const jawBulb = new THREE.Mesh(
      makeOrganicGeometry(new THREE.Vector3(0.61, 0.19, 0.16), 7.2, 30, 20),
      this.materials.skin,
    );
    jawBulb.position.y = -0.06;
    this.lowerJaw.add(jawBulb);
    addTube(this.lowerJaw, [
      new THREE.Vector3(-0.7, 0, 0.01),
      new THREE.Vector3(-0.42, -0.15, 0.065),
      new THREE.Vector3(0, -0.2, 0.09),
      new THREE.Vector3(0.43, -0.14, 0.065),
      new THREE.Vector3(0.7, 0, 0.01),
    ], 0.075, lipMaterial, 28);

    const toothGeometry = new THREE.ConeGeometry(0.055, 0.22, 9);
    for (let i = 0; i < 8; i += 1) {
      const x = -0.53 + i * 0.15;
      const tooth = new THREE.Mesh(toothGeometry, this.materials.tooth);
      tooth.position.set(x, 0.02, 0.1);
      tooth.rotation.z = Math.PI + (i - 3.5) * 0.07;
      tooth.scale.set(0.74 + (i % 3) * 0.18, 0.7 + (i % 2) * 0.36, 0.8);
      mouth.add(tooth);

      const lowerTooth = new THREE.Mesh(toothGeometry, this.materials.tooth);
      lowerTooth.position.set(x + 0.055, 0.06, 0.115);
      lowerTooth.rotation.z = (i - 3.5) * 0.065;
      lowerTooth.scale.set(0.72 + (i % 3) * 0.16, 0.8 + (i % 2) * 0.22, 0.75);
      this.lowerJaw.add(lowerTooth);
    }

    mouth.add(this.lowerJaw);
    this.salivaGroup = new THREE.Group();
    this.salivaGroup.visible = false;
    this.salivaMaterial = new THREE.MeshPhysicalMaterial({
      color: 0xc8b8ad,
      transparent: true,
      opacity: 0.34,
      roughness: 0.08,
      clearcoat: 1,
      clearcoatRoughness: 0.02,
      depthWrite: false,
    });
    for (const x of [-0.3, 0.04, 0.34]) {
      const drool = [
        new THREE.Vector3(x, 0.06, 0.14),
        new THREE.Vector3(x + 0.025, -0.04, 0.16),
        new THREE.Vector3(x - 0.015, -0.17, 0.14),
        new THREE.Vector3(x + 0.018, -0.3, 0.14),
      ];
      addTube(this.salivaGroup, drool, 0.012, this.salivaMaterial, 14);
      const bead = new THREE.Mesh(new THREE.SphereGeometry(0.027, 10, 8), this.salivaMaterial);
      bead.position.copy(drool[drool.length - 1]);
      bead.scale.set(0.78, 1.5, 0.78);
      this.salivaGroup.add(bead);
    }
    mouth.add(this.salivaGroup);
    return mouth;
  }

  update(
    time: number,
    delta: number,
    playerPosition: THREE.Vector3,
    state: MonsterState,
    aggression: number,
    attackDrive: number,
  ): void {
    const breath = Math.sin(time * (1.25 + aggression * 0.55)) * 0.018;
    this.body.scale.set(1 + breath * 0.45, 1 + breath, 1 + breath * 0.25);
    this.body.position.y = 2.38 + Math.sin(time * 0.7) * 0.025;
    this.body.rotation.z = Math.sin(time * 0.38) * 0.012 + Math.sin(time * 3.9) * aggression * 0.008;

    for (const [index, part] of this.bodyParts.entries()) {
      part.scale.x = 1 + Math.sin(time * 1.2 + index) * 0.012 + aggression * 0.018;
    }

    this.eyes.update(time, delta, playerPosition, aggression);
    this.tentacles.update(time, playerPosition, aggression, attackDrive);

    let mouthTarget = 0.035 + aggression * 0.13;
    if (state === "CURIOUS") mouthTarget = 0.17;
    if (state === "AGGRESSIVE") mouthTarget = 0.33 + Math.sin(time * 4.1) * 0.09;
    if (state === "ATTACK") mouthTarget = 0.98;
    if (state === "RECOVERY") mouthTarget = 0.08 + attackDrive * 0.42;
    const opening = THREE.MathUtils.clamp(mouthTarget, 0.025, 1);
    this.mouthOpening.scale.y = 0.22 + opening * 0.55;
    this.lowerJaw.position.y = -0.02 - opening * 0.34;
    this.salivaGroup.visible = opening > 0.35;
    this.salivaGroup.position.y = -opening * 0.055;
    this.salivaGroup.scale.y = 0.48 + opening * 0.56;
    this.salivaMaterial.opacity = 0.24 + opening * 0.23;
  }

  reset(): void {
    this.body.position.set(0, 2.38, 0);
    this.body.rotation.set(0, 0, 0);
    this.maw.rotation.set(0, 0, 0);
  }
}