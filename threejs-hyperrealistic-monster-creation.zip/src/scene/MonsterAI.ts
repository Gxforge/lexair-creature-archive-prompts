import * as THREE from "three";
import type { MonsterState } from "./types";

const clamp = THREE.MathUtils.clamp;

export class MonsterAI {
  state: MonsterState = "WATCHING";
  aggression = 0.2;
  private stateElapsed = 0;
  private attackCooldown = 0;

  get attackDrive(): number {
    if (this.state === "ATTACK") {
      return Math.sin(clamp(this.stateElapsed / 1.22, 0, 1) * Math.PI);
    }
    if (this.state === "RECOVERY") return 0.42 * Math.exp(-this.stateElapsed * 1.15);
    return 0;
  }

  reset(): void {
    this.state = "WATCHING";
    this.aggression = 0.2;
    this.stateElapsed = 0;
    this.attackCooldown = 0;
  }

  update(distance: number, delta: number): void {
    this.stateElapsed += delta;
    this.attackCooldown = Math.max(0, this.attackCooldown - delta);

    if (this.state === "ATTACK") {
      if (this.stateElapsed >= 1.22) this.transition("RECOVERY");
    } else if (this.state === "RECOVERY") {
      if (this.stateElapsed >= 2.15) this.transition(this.stateForDistance(distance));
    } else if (distance < 4.15 && this.attackCooldown <= 0) {
      this.attackCooldown = 6.4;
      this.transition("ATTACK");
    } else {
      this.transition(this.stateForDistance(distance));
    }

    const targets: Record<MonsterState, number> = {
      IDLE: 0.05,
      WATCHING: 0.2,
      CURIOUS: 0.46,
      AGGRESSIVE: 0.79,
      ATTACK: 1,
      RECOVERY: 0.31,
    };
    this.aggression = THREE.MathUtils.damp(this.aggression, targets[this.state], 1.55, delta);
  }

  private stateForDistance(distance: number): MonsterState {
    if (distance > 11.5) return "IDLE";
    if (distance > 7.1) return "WATCHING";
    if (distance > 5.05) return "CURIOUS";
    return "AGGRESSIVE";
  }

  private transition(next: MonsterState): void {
    if (next === this.state) return;
    this.state = next;
    this.stateElapsed = 0;
  }
}