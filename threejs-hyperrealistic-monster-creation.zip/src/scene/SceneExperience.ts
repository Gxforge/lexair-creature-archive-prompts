import * as THREE from "three";
import { EffectComposer } from "three/addons/postprocessing/EffectComposer.js";
import { OutputPass } from "three/addons/postprocessing/OutputPass.js";
import { RenderPass } from "three/addons/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/addons/postprocessing/UnrealBloomPass.js";
import { CameraController, type ViewMode } from "./CameraController";
import { Effects } from "./Effects";
import { Environment } from "./Environment";
import { Monster } from "./Monster";
import { MonsterAI } from "./MonsterAI";
import type { MonsterTelemetry, QualityPreset } from "./types";

export class SceneExperience {
  readonly scene: THREE.Scene;
  readonly camera: THREE.PerspectiveCamera;
  readonly renderer: THREE.WebGLRenderer;
  private composer!: EffectComposer;
  private bloomPass!: UnrealBloomPass;
  readonly cameraController: CameraController;
  readonly monster: Monster;
  readonly ai = new MonsterAI();
  readonly environment: Environment;
  readonly effects = new Effects();
  private clock = new THREE.Clock();
  private animationFrame = 0;
  private elapsed = 0;
  private telemetryTime = 0;
  private active = true;
  private quality: QualityPreset = "high";
  private resizeObserver: ResizeObserver;
  private playerPosition = new THREE.Vector3();
  private onResize = (): void => this.resize();

  constructor(
    private canvas: HTMLCanvasElement,
    private onTelemetry: (telemetry: MonsterTelemetry) => void,
  ) {
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x07090a);
    this.scene.fog = new THREE.FogExp2(0x080b0c, 0.032);

    this.camera = new THREE.PerspectiveCamera(42, 1, 0.1, 85);
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      powerPreference: "high-performance",
      alpha: false,
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.composer = new EffectComposer(this.renderer);
    this.composer.addPass(new RenderPass(this.scene, this.camera));
    this.bloomPass = new UnrealBloomPass(new THREE.Vector2(1, 1), 0.58, 0.58, 0.7);
    this.composer.addPass(this.bloomPass);
    this.composer.addPass(new OutputPass());

    this.environment = new Environment(this.scene);
    this.monster = new Monster();
    this.scene.add(this.monster.group);
    this.scene.add(this.effects.group);
    this.cameraController = new CameraController(this.camera, canvas);
    this.resizeObserver = new ResizeObserver(this.onResize);
    this.resizeObserver.observe(canvas.parentElement ?? canvas);
    window.addEventListener("resize", this.onResize);

    this.resize();
    this.setQuality("high");
    this.clock.start();
    this.tick();
  }

  private tick = (): void => {
    this.animationFrame = window.requestAnimationFrame(this.tick);
    const delta = Math.min(this.clock.getDelta(), 0.05);
    this.elapsed += delta;

    this.cameraController.update(delta);
    this.cameraController.getPlayerPosition(this.playerPosition);
    const distance = this.cameraController.getDistance();

    if (this.active) {
      this.ai.update(distance, delta);
      this.monster.update(
        this.elapsed,
        delta,
        this.playerPosition,
        this.ai.state,
        this.ai.aggression,
        this.ai.attackDrive,
      );
      this.environment.update(this.elapsed, this.ai.aggression);
      this.effects.update(this.elapsed, delta, this.camera, this.ai.attackDrive);
    }

    this.telemetryTime += delta;
    if (this.telemetryTime > 0.12) {
      this.telemetryTime = 0;
      this.onTelemetry({
        state: this.ai.state,
        distance,
        aggression: this.ai.aggression,
        threat: this.ai.aggression,
      });
    }

    this.composer.render(delta);
  };

  private resize(): void {
    const element = this.canvas.parentElement ?? this.canvas;
    const width = Math.max(1, element.clientWidth || window.innerWidth);
    const height = Math.max(1, element.clientHeight || window.innerHeight);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    const pixelRatio = this.pixelRatioForQuality();
    this.renderer.setPixelRatio(pixelRatio);
    this.renderer.setSize(width, height, false);
    this.composer.setPixelRatio(pixelRatio);
    this.composer.setSize(width, height);
  }

  private pixelRatioForQuality(): number {
    const ratios: Record<QualityPreset, number> = { low: 0.85, medium: 1.15, high: 1.65 };
    return Math.min(window.devicePixelRatio || 1, ratios[this.quality]);
  }

  setQuality(quality: QualityPreset): void {
    this.quality = quality;
    const shadowsEnabled = quality === "high";
    this.renderer.shadowMap.enabled = shadowsEnabled;
    this.bloomPass.enabled = quality !== "low";
    this.bloomPass.strength = quality === "high" ? 0.58 : 0.38;
    for (const light of this.environment.allLights) {
      light.castShadow = shadowsEnabled && (light instanceof THREE.DirectionalLight || light instanceof THREE.SpotLight);
    }
    this.effects.setQuality(quality);
    this.resize();
  }

  setActive(active: boolean): void {
    this.active = active;
    this.clock.getDelta();
  }

  setViewMode(mode: ViewMode): void {
    this.cameraController.setMode(mode);
  }

  reset(): void {
    this.elapsed = 0;
    this.ai.reset();
    this.monster.reset();
    this.cameraController.reset();
    this.onTelemetry({
      state: this.ai.state,
      distance: this.cameraController.getDistance(),
      aggression: this.ai.aggression,
      threat: this.ai.aggression,
    });
  }

  dispose(): void {
    window.cancelAnimationFrame(this.animationFrame);
    this.resizeObserver.disconnect();
    window.removeEventListener("resize", this.onResize);
    this.cameraController.dispose();

    const geometries = new Set<THREE.BufferGeometry>();
    const materials = new Set<THREE.Material>();
    const textures = new Set<THREE.Texture>();
    this.scene.traverse((object) => {
      const mesh = object as THREE.Mesh;
      if (mesh.geometry) geometries.add(mesh.geometry);
      if (Array.isArray(mesh.material)) mesh.material.forEach((material) => materials.add(material));
      else if (mesh.material) materials.add(mesh.material);
    });
    for (const material of materials) {
      for (const value of Object.values(material)) {
        if (value instanceof THREE.Texture) textures.add(value);
      }
      material.dispose();
    }
    geometries.forEach((geometry) => geometry.dispose());
    textures.forEach((texture) => texture.dispose());
    this.composer.dispose();
    this.renderer.dispose();
  }
}