import * as THREE from "three";
import type { MaterialSet } from "./types";

interface SuckerRig {
  root: THREE.Group;
  along: number;
  radius: number;
}

interface TentacleRig {
  root: THREE.Group;
  mesh: THREE.Mesh<THREE.BufferGeometry, THREE.MeshPhysicalMaterial>;
  curve: THREE.CatmullRomCurve3;
  controls: THREE.Vector3[];
  baseDirection: THREE.Vector3;
  phase: number;
  length: number;
  radius: number;
  speed: number;
  geometry: THREE.BufferGeometry;
  suckers: SuckerRig[];
}

const TUBE_SEGMENTS = 28;
const RADIAL_SEGMENTS = 9;

const anchors = [
  { p: [-1.48, 3.03, 0.12], d: [-1, 0.22, 0.08], length: 2.65, radius: 0.22 },
  { p: [1.48, 3.08, 0.12], d: [1, 0.13, 0.1], length: 2.5, radius: 0.21 },
  { p: [-1.42, 2.51, 0.32], d: [-1, -0.19, 0.06], length: 2.85, radius: 0.24 },
  { p: [1.39, 2.48, 0.34], d: [1, -0.27, 0.06], length: 3.05, radius: 0.24 },
  { p: [-1.01, 1.87, 0.25], d: [-0.72, -0.77, 0.15], length: 2.7, radius: 0.2 },
  { p: [1.01, 1.82, 0.25], d: [0.76, -0.68, 0.13], length: 2.85, radius: 0.21 },
  { p: [-0.77, 3.55, -0.25], d: [-0.52, 0.84, -0.24], length: 1.95, radius: 0.17 },
  { p: [0.79, 3.52, -0.22], d: [0.56, 0.79, -0.21], length: 2.15, radius: 0.18 },
  { p: [-1.11, 2.17, -0.31], d: [-0.94, -0.08, -0.48], length: 2.45, radius: 0.18 },
  { p: [1.1, 2.14, -0.31], d: [0.91, -0.08, -0.52], length: 2.35, radius: 0.18 },
];

function buildTubeGeometry(curve: THREE.CatmullRomCurve3, radius: number): THREE.BufferGeometry {
  const geometry = new THREE.BufferGeometry();
  const vertices = (TUBE_SEGMENTS + 1) * (RADIAL_SEGMENTS + 1);
  const positions = new Float32Array(vertices * 3);
  const uvs = new Float32Array(vertices * 2);
  const indices: number[] = [];

  for (let i = 0; i <= TUBE_SEGMENTS; i += 1) {
    for (let j = 0; j <= RADIAL_SEGMENTS; j += 1) {
      const index = i * (RADIAL_SEGMENTS + 1) + j;
      uvs[index * 2] = i / TUBE_SEGMENTS;
      uvs[index * 2 + 1] = j / RADIAL_SEGMENTS;
      if (i < TUBE_SEGMENTS && j < RADIAL_SEGMENTS) {
        const a = index;
        const b = index + RADIAL_SEGMENTS + 1;
        indices.push(a, a + 1, b, b, a + 1, b + 1);
      }
    }
  }

  geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute("uv", new THREE.BufferAttribute(uvs, 2));
  geometry.setIndex(indices);
  updateTubeGeometry(geometry, curve, radius);
  return geometry;
}

function updateTubeGeometry(
  geometry: THREE.BufferGeometry,
  curve: THREE.CatmullRomCurve3,
  baseRadius: number,
): void {
  const frames = curve.computeFrenetFrames(TUBE_SEGMENTS, false);
  const position = geometry.getAttribute("position") as THREE.BufferAttribute;

  for (let i = 0; i <= TUBE_SEGMENTS; i += 1) {
    const u = i / TUBE_SEGMENTS;
    const point = curve.getPointAt(u);
    const radius = baseRadius * Math.pow(1 - u, 0.78) + 0.012;
    const normal = frames.normals[i];
    const binormal = frames.binormals[i];

    for (let j = 0; j <= RADIAL_SEGMENTS; j += 1) {
      const angle = (j / RADIAL_SEGMENTS) * Math.PI * 2;
      const radial = normal.clone().multiplyScalar(Math.cos(angle))
        .add(binormal.clone().multiplyScalar(Math.sin(angle)));
      const vertex = point.clone().addScaledVector(radial, radius);
      position.setXYZ(i * (RADIAL_SEGMENTS + 1) + j, vertex.x, vertex.y, vertex.z);
    }
  }

  position.needsUpdate = true;
  geometry.computeVertexNormals();
  geometry.computeBoundingSphere();
}

export class Tentacles {
  readonly group = new THREE.Group();
  private rigs: TentacleRig[] = [];

  constructor(private materials: MaterialSet) {
    this.group.name = "living-tentacles";
    anchors.forEach((anchor, index) => this.addTentacle(anchor, index));
  }

  private addTentacle(
    anchor: (typeof anchors)[number],
    index: number,
  ): void {
    const root = new THREE.Group();
    root.position.set(anchor.p[0], anchor.p[1], anchor.p[2]);
    this.group.add(root);

    const direction = new THREE.Vector3(...anchor.d).normalize();
    const length = anchor.length;
    const controls = [
      new THREE.Vector3(0, 0, 0),
      direction.clone().multiplyScalar(length * 0.26).add(new THREE.Vector3(0, 0.08, 0)),
      direction.clone().multiplyScalar(length * 0.53),
      direction.clone().multiplyScalar(length * 0.79),
      direction.clone().multiplyScalar(length),
    ];
    const curve = new THREE.CatmullRomCurve3(controls, false, "catmullrom", 0.42);
    const geometry = buildTubeGeometry(curve, anchor.radius);
    const mesh = new THREE.Mesh(geometry, this.materials.skin);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    root.add(mesh);

    const suckers: SuckerRig[] = [];
    const suckerCount = index % 3 === 0 ? 5 : 4;
    for (let i = 0; i < suckerCount; i += 1) {
      const along = 0.32 + i * 0.115;
      const rig = new THREE.Group();
      const cup = new THREE.Mesh(
        new THREE.TorusGeometry(anchor.radius * (0.48 - i * 0.035), anchor.radius * 0.12, 7, 16),
        this.materials.sucker,
      );
      cup.scale.y = 0.77;
      const center = new THREE.Mesh(
        new THREE.SphereGeometry(anchor.radius * 0.31, 12, 8),
        this.materials.socket,
      );
      center.scale.set(1, 0.72, 0.38);
      center.position.z = 0.006;
      rig.add(cup, center);
      root.add(rig);
      suckers.push({ root: rig, along, radius: anchor.radius });
    }

    this.rigs.push({
      root,
      mesh,
      curve,
      controls,
      baseDirection: direction,
      phase: index * 1.23,
      length,
      radius: anchor.radius,
      speed: 0.56 + (index % 4) * 0.11,
      geometry,
      suckers,
    });
  }

  update(
    time: number,
    playerPosition: THREE.Vector3,
    aggression: number,
    attackDrive: number,
  ): void {
    for (const rig of this.rigs) {
      const target = playerPosition.clone().sub(rig.root.position).normalize();
      const targetPull = 0.05 + aggression * 0.15 + attackDrive * 0.28;
      const extension = 1 + aggression * 0.1 + attackDrive * 0.34;
      const sway = Math.sin(time * rig.speed + rig.phase);
      const twitch = Math.sin(time * (2.4 + rig.speed) + rig.phase * 2.7);
      const cross = new THREE.Vector3(-rig.baseDirection.y, rig.baseDirection.x, 0).normalize();

      for (let i = 1; i < rig.controls.length; i += 1) {
        const along = i / (rig.controls.length - 1);
        const reach = rig.length * along * extension;
        const point = rig.baseDirection.clone().multiplyScalar(reach);
        point.addScaledVector(target, reach * targetPull * along);
        point.addScaledVector(cross, (sway * 0.23 + twitch * 0.065) * along * along);
        point.y += Math.sin(time * 1.65 + rig.phase + along * 4.5) * 0.12 * along;
        point.z += Math.cos(time * 1.1 + rig.phase + along * 3.7) * 0.1 * along;
        rig.controls[i].copy(point);
      }

      rig.curve.updateArcLengths();
      updateTubeGeometry(rig.geometry, rig.curve, rig.radius * (1 + aggression * 0.07));

      for (const sucker of rig.suckers) {
        const point = rig.curve.getPointAt(sucker.along);
        const direction = rig.curve.getTangentAt(sucker.along);
        sucker.root.position.copy(point);
        const facing = new THREE.Vector3(0, 0, 1).addScaledVector(direction, -direction.z).normalize();
        sucker.root.position.addScaledVector(facing, sucker.radius * 0.62);
        sucker.root.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), facing);
        const pulse = 1 + Math.sin(time * 3.1 + rig.phase + sucker.along * 5) * 0.08;
        sucker.root.scale.setScalar(pulse);
      }
    }
  }
}