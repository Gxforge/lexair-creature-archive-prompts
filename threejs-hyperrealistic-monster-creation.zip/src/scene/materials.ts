import * as THREE from "three";
import type { MaterialSet } from "./types";

function createSkinTexture(): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 1024;
  canvas.height = 512;
  const context = canvas.getContext("2d");

  if (!context) throw new Error("Canvas textures are not available in this browser.");

  const image = context.createImageData(canvas.width, canvas.height);
  for (let i = 0; i < image.data.length; i += 4) {
    const grain = Math.random() * 26;
    image.data[i] = 90 + grain;
    image.data[i + 1] = 44 + grain * 0.55;
    image.data[i + 2] = 52 + grain * 0.62;
    image.data[i + 3] = 255;
  }
  context.putImageData(image, 0, 0);

  for (let i = 0; i < 58; i += 1) {
    const x = Math.random() * canvas.width;
    const y = Math.random() * canvas.height;
    const radius = 18 + Math.random() * 100;
    const shade = Math.random() > 0.5 ? "rgba(181, 88, 91, 0.18)" : "rgba(27, 16, 20, 0.22)";
    const patch = context.createRadialGradient(x, y, 0, x, y, radius);
    patch.addColorStop(0, shade);
    patch.addColorStop(1, "rgba(0, 0, 0, 0)");
    context.fillStyle = patch;
    context.fillRect(x - radius, y - radius, radius * 2, radius * 2);
  }

  for (let i = 0; i < 40; i += 1) {
    const startX = Math.random() * canvas.width;
    const startY = Math.random() * canvas.height;
    context.beginPath();
    context.moveTo(startX, startY);
    context.bezierCurveTo(
      startX + (Math.random() - 0.5) * 90,
      startY + 30 + Math.random() * 55,
      startX + (Math.random() - 0.5) * 140,
      startY - 40 + Math.random() * 120,
      startX + (Math.random() - 0.5) * 170,
      startY + (Math.random() - 0.5) * 180,
    );
    context.strokeStyle = `rgba(190, 75, 83, ${0.12 + Math.random() * 0.18})`;
    context.lineWidth = 1 + Math.random() * 2.2;
    context.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(1.5, 1.15);
  texture.anisotropy = 4;
  return texture;
}

function createIrisTexture(): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const context = canvas.getContext("2d");

  if (!context) throw new Error("Canvas textures are not available in this browser.");

  const center = size / 2;
  const gradient = context.createRadialGradient(center, center, 20, center, center, center);
  gradient.addColorStop(0, "#180d11");
  gradient.addColorStop(0.23, "#52252d");
  gradient.addColorStop(0.42, "#a74d3e");
  gradient.addColorStop(0.64, "#73342f");
  gradient.addColorStop(0.84, "#c18055");
  gradient.addColorStop(1, "#32181d");
  context.fillStyle = gradient;
  context.fillRect(0, 0, size, size);

  for (let i = 0; i < 310; i += 1) {
    const angle = (i / 310) * Math.PI * 2 + (Math.random() - 0.5) * 0.07;
    const inner = 58 + Math.random() * 42;
    const outer = 135 + Math.random() * 100;
    context.beginPath();
    context.moveTo(center + Math.cos(angle) * inner, center + Math.sin(angle) * inner);
    context.lineTo(center + Math.cos(angle) * outer, center + Math.sin(angle) * outer);
    context.strokeStyle = ["rgba(237, 161, 102, .5)", "rgba(37, 13, 22, .62)", "rgba(213, 89, 62, .48)"][i % 3];
    context.lineWidth = 1 + Math.random() * 2.1;
    context.stroke();
  }

  for (let ring = 0; ring < 5; ring += 1) {
    context.beginPath();
    context.arc(center, center, 130 + ring * 21, 0, Math.PI * 2);
    context.strokeStyle = `rgba(235, ${130 + ring * 10}, 82, ${0.22 + ring * 0.035})`;
    context.lineWidth = ring % 2 === 0 ? 2 : 1;
    context.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 8;
  return texture;
}

export function createMaterialSet(): MaterialSet {
  const skinTexture = createSkinTexture();
  const irisTexture = createIrisTexture();

  return {
    skin: new THREE.MeshPhysicalMaterial({
      map: skinTexture,
      color: 0xe6c4c3,
      roughness: 0.39,
      metalness: 0.015,
      clearcoat: 0.38,
      clearcoatRoughness: 0.23,
      bumpMap: skinTexture,
      bumpScale: 0.07,
    }),
    skinLight: new THREE.MeshPhysicalMaterial({
      color: 0x9c666c,
      roughness: 0.34,
      clearcoat: 0.45,
      clearcoatRoughness: 0.2,
    }),
    socket: new THREE.MeshPhysicalMaterial({
      color: 0x392126,
      roughness: 0.28,
      clearcoat: 0.55,
      clearcoatRoughness: 0.16,
    }),
    pore: new THREE.MeshStandardMaterial({ color: 0x271319, roughness: 0.62 }),
    eyeWhite: new THREE.MeshPhysicalMaterial({
      color: 0xd2c7bb,
      roughness: 0.2,
      clearcoat: 1,
      clearcoatRoughness: 0.08,
    }),
    iris: new THREE.MeshPhysicalMaterial({
      map: irisTexture,
      roughness: 0.3,
      metalness: 0.08,
      clearcoat: 0.7,
      clearcoatRoughness: 0.18,
      emissive: 0x341011,
      emissiveIntensity: 0.3,
    }),
    pupil: new THREE.MeshBasicMaterial({ color: 0x050405 }),
    cornea: new THREE.MeshPhysicalMaterial({
      color: 0xe8e5dd,
      transparent: true,
      opacity: 0.19,
      roughness: 0.035,
      metalness: 0,
      clearcoat: 1,
      clearcoatRoughness: 0.015,
      depthWrite: false,
    }),
    vein: new THREE.MeshStandardMaterial({ color: 0x902e39, roughness: 0.45 }),
    mouth: new THREE.MeshStandardMaterial({ color: 0x16090d, roughness: 0.2 }),
    tooth: new THREE.MeshPhysicalMaterial({
      color: 0xd9c9af,
      roughness: 0.22,
      clearcoat: 0.8,
    }),
    sucker: new THREE.MeshPhysicalMaterial({
      color: 0x602e35,
      roughness: 0.27,
      clearcoat: 0.55,
      clearcoatRoughness: 0.16,
    }),
  };
}

export function createFloorTexture(): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 512;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Canvas textures are not available in this browser.");

  context.fillStyle = "#202323";
  context.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 14000; i += 1) {
    const shade = Math.floor(18 + Math.random() * 35);
    context.fillStyle = `rgba(${shade + 4}, ${shade + 5}, ${shade + 4}, ${Math.random() * 0.34})`;
    context.fillRect(Math.random() * 512, Math.random() * 512, 1 + Math.random() * 4, 1 + Math.random() * 3);
  }
  context.strokeStyle = "rgba(7, 9, 10, .45)";
  context.lineWidth = 3;
  for (let i = 0; i < 9; i += 1) {
    const x = i * 64;
    context.beginPath();
    context.moveTo(x, 0);
    context.lineTo(x + (Math.random() - 0.5) * 30, 512);
    context.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(6, 6);
  texture.anisotropy = 4;
  return texture;
}