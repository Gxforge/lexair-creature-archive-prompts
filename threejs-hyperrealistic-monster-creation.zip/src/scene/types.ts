export type MonsterState =
  | "IDLE"
  | "WATCHING"
  | "CURIOUS"
  | "AGGRESSIVE"
  | "ATTACK"
  | "RECOVERY";

export type QualityPreset = "low" | "medium" | "high";

export interface MonsterTelemetry {
  state: MonsterState;
  distance: number;
  aggression: number;
  threat: number;
}

export interface MaterialSet {
  skin: import("three").MeshPhysicalMaterial;
  skinLight: import("three").MeshPhysicalMaterial;
  socket: import("three").MeshPhysicalMaterial;
  pore: import("three").MeshStandardMaterial;
  eyeWhite: import("three").MeshPhysicalMaterial;
  iris: import("three").MeshPhysicalMaterial;
  pupil: import("three").MeshBasicMaterial;
  cornea: import("three").MeshPhysicalMaterial;
  vein: import("three").MeshStandardMaterial;
  mouth: import("three").MeshStandardMaterial;
  tooth: import("three").MeshPhysicalMaterial;
  sucker: import("three").MeshPhysicalMaterial;
}